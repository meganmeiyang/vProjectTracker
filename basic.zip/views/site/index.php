<?php

/* @var $this yii\web\View */

$this->title = 'LinksField Project Tracker';
?>
<div class="site-index">

    <div class="jumbotron">
        <h3>Welcome!</h3>

        <p class="lead">This is the LinksField Overseas Project Tracker. </p>

        <p><a class="btn btn-lg btn-success" href="?r=project%2Findex">Enter Projects</a></p>
    </div>

    
    
</div>
