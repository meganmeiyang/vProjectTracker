<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        This project tracker is for LinksField Oversea project tracking. 
	</p>
	<P>Visitors can view only. 
	
		Logged in admin and users are able to create and update.
	</p>
	<p>	
		- developed by Megan Yang Mei.
		
    </p>

   
</div>
